package com.dreamwalker.flutter_notebook_chapter_23

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
