# flutter_notebook_chapter_23

## S26

### EP1345 -1350

- Shopink - E-Commerce
- by Rizal🔥 for Kretya
- https://dribbble.com/shots/19972519-Shopink-E-Commerce

<img src="https://cdn.dribbble.com/userupload/4051770/file/original-033e11fd233020a4a9807133f513a380.png?compress=1&resize=1600x1200" width="400px"/>

### EP1343-1344

- Sales Reports App
- by Awsmd
- https://dribbble.com/shots/19922240-Taxi-App-Driver-s-Profile

<img src="https://cdn.dribbble.com/userupload/4025425/file/original-8e8389e1bd85b11edf4ab19c25394577.png?compress=1&resize=1600x1200" width="400px"/>

### EP1340-1342

- Sales Reports App
- by Awsmd
- https://dribbble.com/shots/19928539-Sales-Reports-App

<img src="https://cdn.dribbble.com/userupload/4027431/file/original-4603765b2b5eb9752f13ff7bf5d7acb3.png?compress=1&resize=1600x1200" width="400px"/>

### EP1335-1339

- Dating App Design Mobile App
- by lazy kar for LazyInterface | UI UX Team
- https://dribbble.com/shots/19877932-Dating-App-Design-Mobile-App

<img src="https://cdn.dribbble.com/userupload/3997306/file/original-dafa3f7f3ebdb5c38032b5c954c14d5f.png?compress=1&resize=1600x1200" width="400px"/>

### EP1331-1334

- Property Rental App
- by Tanuj agarwal for Nickelfox
- https://dribbble.com/shots/19857568-Property-Rental-App

<img src="https://cdn.dribbble.com/users/5701416/screenshots/19857568/media/b3798bdb76a80792994a0c4198e7e652.png?compress=1&resize=1000x750&vertical=top" width="400px"/>

### EP1325-1330

- Bus Ticket Booking 🚌 - Mobile App
- by Aleksandr Shchilkin
- https://dribbble.com/shots/19806705-Bus-Ticket-Booking-Mobile-App

<img src="https://cdn.dribbble.com/userupload/3938193/file/original-a7b97f5b3284d3edfa368e34f5054d2a.png?compress=1&resize=1600x1200" width="400px"/>

### EP1321-1324

- Modal components
- by Monty Hayton
- https://dribbble.com/shots/19772253-Modal-components

<img src="https://cdn.dribbble.com/userupload/3910821/file/original-3adeb3b9cabf99102bf3ba71d648c554.png?compress=1&resize=1600x1200" width="400px"/>

### EP1317-1320

- Live Score with Dynamic Island
- by Happy Tri Milliarta for Odama
- https://dribbble.com/shots/19735036-Live-Score-with-Dynamic-Island

<img src="https://cdn.dribbble.com/userupload/3877267/file/original-58f3ad73f06735c0f88b75b81c3caf7b.png?compress=1&resize=1600x1200" width="400px"/>

### EP1313-1316

- A new look for the UFC
- by Giorgi J. for Ascended
- https://dribbble.com/shots/19713317-A-new-look-for-the-UFC

<img src="https://cdn.dribbble.com/userupload/3858410/file/original-e962ece67a644f6bbee470084475696d.png?compress=1&resize=1200x900" width="400px"/>

### EP1310-1312

- Material Me — Material You Design system & 💬 Forms templates
- by Felix
- https://dribbble.com/shots/18895046-Material-Me-Material-You-Design-system-Forms-templates/attachments/14070070?mode=media

<img src="https://cdn.dribbble.com/users/1047314/screenshots/18895046/media/3a8e189efb0cdba805fec058a2db617c.jpg" width="400px"/>

### EP1305-1309

- Ecommerce App
- by Emmanuel Edokpa
- https://dribbble.com/shots/19638735-Ecommerce-App

<img src="https://cdn.dribbble.com/userupload/3793994/file/original-2c929bda0d6cdc64d9cdf27846f64113.jpg?compress=1&resize=1200x900" width="400px"/>

### EP1301-1304

- Homby - Smart Home App
- by Raafi G
- https://dribbble.com/shots/19613943-Homby-Smart-Home-App

<img src="https://cdn.dribbble.com/userupload/3772683/file/original-af4799a6c5239b4028fe72063ae07ec0.png?compress=1&resize=1024x768" width="400px"/>


A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials, samples, guidance on
mobile development, and a full API reference.
